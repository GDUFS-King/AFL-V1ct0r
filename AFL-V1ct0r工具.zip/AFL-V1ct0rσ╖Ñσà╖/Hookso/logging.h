#pragma once

extern int debug_info_on;

void debug_info(char *, ...);