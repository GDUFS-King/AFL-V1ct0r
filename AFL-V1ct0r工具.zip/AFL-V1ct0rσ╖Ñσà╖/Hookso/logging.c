#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

int debug_info_on = 0;

int debug_info(char *fmt, ...)
{
	if (!debug_info_on) 
	{
		return 0;
	}
	else
	{
		printf("\n-----Debugging Information-----\n");
		va_list args;
		va_start(args,fmt);
		vprintf(fmt,args);
		va_end(args);
		fflush(stdout);
	}
	
}

__attribute__((constructor)) void log_init()
{
	debug_info_on = debug_info_on || (getenv("DEBUG_INFO") && (strcmp(getenv("DEBUG_INFO"), "1") == 0));
}
