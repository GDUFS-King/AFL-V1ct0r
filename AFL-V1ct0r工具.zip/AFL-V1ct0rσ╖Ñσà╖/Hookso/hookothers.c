#define _GNU_SOURCE

#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>
#include <poll.h>

#include "logging.h"

int hookalarm_flag = 0;

int hookfork_flag = 0;

int hookptrace_flag = 0;

int hooksleep_flag = 0;
int hookusleep_flag = 0;

int hookrand_flag = 0;

int hookrand_r_flag = 0;

int hooksrand_flag = 0;
int hookfunc = 0;

#pragma GCC diagnostic ignored "-Wpointer-to-int-cast"
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"


// originals

unsigned int (*original_sleep)(unsigned int s);

int (*original_usleep)(unsigned int s);

pid_t (*original_fork)(void);

long (*original_ptrace)(int a, int b, int c, int d);

unsigned int (*original_alarm)(unsigned int s);

int (*original_rand)(void);

int (*original_rand_r)(unsigned int *a);

void (*original_srand)(unsigned int s);

__attribute__((constructor)) void Get_origianl_otherfunc()
{

	original_alarm = dlsym(RTLD_NEXT, "alarm");

	original_ptrace = dlsym(RTLD_NEXT, "ptrace");

	original_fork = dlsym(RTLD_NEXT, "fork");

	original_sleep = dlsym(RTLD_NEXT, "sleep");

	original_usleep= dlsym(RTLD_NEXT, "usleep");

	original_rand = dlsym(RTLD_NEXT, "rand");

	original_rand_r = dlsym(RTLD_NEXT, "rand_r");

	original_srand = dlsym(RTLD_NEXT, "srand");
}

__attribute__((destructor)) void Complete_all_function()
{
	debug_info("Shutdown complete!.....\n");
}

int rand(void)
{
	if(hookrand_flag)
	{
		debug_info("Hook rand and return 777!!!\n");
		return 777;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_rand();
	}
}

int rand_r(unsigned int *a)
{
	if(hookrand_r_flag)
	{
		debug_info("Hook rand_r and return 777!!!\n");
		return 777;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_rand_r(a);
	}
}


void srand(unsigned int s)
{
	if(hooksrand_flag)
	{
		debug_info("Hook srand and change seed to 1!!!\n");
		original_srand(1);
	}
	else
	{
		debug_info("Original funciton~\n");
		original_srand(s);
	}
}

int usleep(unsigned int s)
{
   if(hookusleep_flag)
	{
		debug_info("Hook usleep now!!!\n");
		return 0;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_usleep(s);
	}

}


unsigned int sleep(unsigned int s)
{
  if(hooksleep_flag)
	{
		debug_info("Hook sleep now!!!\n");
		return 0;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_sleep(s);
	}
}

long ptrace(int a, int b, int c, int d)
{
	if(hookptrace_flag)
	{
		debug_info("Hook ptrace now!!!\n");
		return 0;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_ptrace(a,b,c,d);
	}
}

pid_t fork(void) 
{
    if(hookfork_flag)
	{
		debug_info("Hook fork now!!!\n");
		return 0;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_fork();
	}
}

unsigned int alarm(unsigned int s)
{
	if(hookalarm_flag)
	{
		debug_info("Hook alarm now!!!\n");
		return 0;
	}
	else
	{
		debug_info("Original funciton~\n");
		return original_alarm(s);
	}
	
}


