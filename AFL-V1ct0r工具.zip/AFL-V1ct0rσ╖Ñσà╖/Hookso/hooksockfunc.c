#define _GNU_SOURCE


#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>
#include <poll.h>

#include "logging.h"
#define PORT 9877
//设置函数ｈｏｏｋ的开关，１开启，０关闭
int hooksock_flag = 0;

int hookrecv_flag = 1;
int hooksend_flag = 1;
// int hookread_flag = 0;
// int hookwrite_flag = 0;
int hooksendto_flag = 0;
int hookrecvfrom_flag = 0;
int hooklisten_flag = 0;
int hookconnect_flag = 0;
int hookgetsocketname_flag = 0;
int hookclose_flag = 0;
int hookbind_flag = 0;
int hookaccept_flag = 0;
int hookaccept4_flag= 0;
int hookshutdown_flag= 0;


#pragma GCC diagnostic ignored "-Wpointer-to-int-cast"
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"


//原始函数声明
// ssize_t (*original_read)(int fd, void * buf, size_t count);
// ssize_t (*original_write)(int fd, const void * buf, size_t count);

int (*original_socket)(int domain, int type, int protocol);
ssize_t (*original_send)(int fd,const void *buf,size_t len,int flags);
ssize_t (*original_recv)(int fd,void *buf,size_t len,int flags);

ssize_t (*original_sendto)(int __fd, __const void *__buf, size_t __n,int __flags, __CONST_SOCKADDR_ARG __addr,socklen_t __addr_len);
ssize_t (*original_recvfrom)(int __fd, void *__restrict __buf, size_t __n,int __flags, __SOCKADDR_ARG __addr,socklen_t *__restrict __addr_len);

int (*original_bind)(int, const struct sockaddr *, socklen_t);
int (*original_listen)(int, int);
int (*original_accept)(int, struct sockaddr *, socklen_t *);
int (*original_connect)(int sockfd, const struct sockaddr *addr, socklen_t addrlen);

int (*original_close)(int fd);
int (*original_shutdown)(int sockfd, int how);

int (*original_getsockname)(int sockfd, struct sockaddr *addr, socklen_t *addrlen);

//在调用前先获取到库中相应的函数
__attribute__((constructor)) void Get_origianl_socketfunc()
{
	original_socket = dlsym(RTLD_NEXT, "socket");
	original_listen = dlsym(RTLD_NEXT, "listen");
	original_accept = dlsym(RTLD_NEXT, "accept");
	original_bind = dlsym(RTLD_NEXT, "bind");
	// original_read = dlsym(RTLD_NEXT, "read");
	// original_write = dlsym(RTLD_NEXT, "write");

	original_send = dlsym(RTLD_NEXT, "send");
	original_recv = dlsym(RTLD_NEXT, "recv");

	original_sendto = dlsym(RTLD_NEXT, "sendto");
	original_recvfrom = dlsym(RTLD_NEXT, "recvfrom");

	original_connect = dlsym(RTLD_NEXT, "connect");

	original_close = dlsym(RTLD_NEXT, "close");
	original_shutdown = dlsym(RTLD_NEXT, "shutdown");

	original_getsockname = dlsym(RTLD_NEXT, "getsockname");

}

//调用结束后的提示信息
__attribute__((destructor)) void Complete_all_things()
{
	debug_info("... shutdown complete!\n");
}

// ssize_t read(int fd, void *buf, size_t count)
// {
// 	if(hookread_flag)
// 	{
// 		debug_info("Now hooking read!!!\n");
// 		return original_read(0,buf,count);
// 	}
// 	else
// 	{
// 		debug_info("Nomal read function~\n");
// 		return original_read(fd,buf,count);
		
// 	}
// }

// ssize_t write(int fd, const void *buf, size_t count)
// {
// 	if(hookwrite_flag)
// 	{
// 		debug_info("Now hooking write!!!\n");
// 		return original_write(1,buf,count);
// 	}
// 	else
// 	{
// 		debug_info("Nomal write function~\n");
// 		return original_write(fd,buf,count);	
// 	}
// }

int socket(int domain, int type, int protocol)
{
	if(hooksock_flag)
	{
		debug_info("Now hooking socket!!!\n");
		return 3; 
	}
	else
	{
		debug_info("Nomal socket function~\n");
		return original_socket(domain,type,protocol);
		
	}
}
ssize_t sendto(int fd, __const void *buf, size_t len,int flags, __CONST_SOCKADDR_ARG to,socklen_t tolen)
{
	if(hooksendto_flag)
	{
		debug_info("Change sendto to write!!!\n");
		return write(1,buf,len);
	}
	else
	{
		debug_info("Nomal sendto function~\n");
		return sendto(fd,buf,len,flags,(struct sockaddr *)&to,tolen);
	}
}

ssize_t recvfrom(int fd, void *__restrict buf, size_t len,int flags, __SOCKADDR_ARG from,socklen_t *__restrict fromlen)
{
	if(hookrecvfrom_flag)
	{
		debug_info("Change recvfrom to read!!!\n");
		return read(0,buf,len);
	}
	else
	{
		debug_info("Nomal recvfrom function~\n");
		return recvfrom(fd,buf,len,flags,(struct sockaddr *)&from,fromlen);
	}
}


ssize_t recv(int fd,void *buf,size_t len,int flags)
{
	if(hookrecv_flag)
	{
		// debug_info("Change recv to read!!!\n");
		return read(0,buf,len);
	}
	else
	{
		// debug_info("Nomal recv function~\n");
		return recv(fd,buf,len,flags);
	}
	
}

ssize_t send(int fd,const void *buf,size_t len,int flags)
{
	if(hookrecv_flag)
	{
		debug_info("Change send to write!!!\n");
		return write(1,buf,len);
	}
	else
	{
		debug_info("Nomal send function~\n");
		return send(fd,buf,len,flags);
	}
	
}

int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen)
{
	if(hookaccept_flag)
	{
		debug_info("Now hooking accept!!!\n");
		return 1;
	}
	else
	{
		debug_info("Nomal accept function~\n");
		return original_accept(sockfd, addr, addrlen);
	}
	
}

int accept4(int sockfd, struct sockaddr *addr, socklen_t *addrlen, int flags)
{
    if(hookaccept4_flag)
	{
		debug_info("Now hooking accept4!!!\n");
		return 1;
	}
	else
	{
		debug_info("Accept4 is the accept~\n");
		return original_accept(sockfd, addr, addrlen);
	}
}

int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen)
{
	if (hookbind_flag)
	{
		debug_info("Now hooking bind!!!\n");
		return 0;
	}
	else
	{
		debug_info("Nomal bind function~\n");
		return original_bind(sockfd,addr,addrlen);
		
	}
}

int listen(int sockfd, int backlog)
{
	if (hooklisten_flag)
	{
		debug_info("Now hooking listen!!!\n");
		return 0;
	}
	else
	{
		debug_info("Nomal bind function~\n");
		return original_listen(sockfd,backlog);
		
	}

}

int connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen)
{
	if (hookconnect_flag)
	{
		debug_info("Now hooking connect!!!\n");
		return 0;
	}
	else
	{
		debug_info("Nomal bind function~\n");
		return original_connect(sockfd,addr,addrlen);
		
	}
}

int close(int fd) 
{
	if (hookclose_flag)
	{
		debug_info("Now hooking close!!!\n");
		return 0;
	}
	else
	{
		debug_info("Nomal bind function~\n");
		return original_close(fd);
	}
}

int shutdown(int sockfd, int how) 
{
	if (hookshutdown_flag)
	{
		debug_info("Now hooking shutdown!!!\n");
		return 0;
	}
	else
	{
		debug_info("Nomal shutdown function~\n");
		return original_shutdown(sockfd, how);
	}
}

int getsockname(int sockfd, struct sockaddr *addr, socklen_t *addrlen)
{
	struct sockaddr_in target;
	socklen_t copylen = sizeof(target);
	debug_info("Initialize our own socket~\n");

	if (hookgetsocketname_flag)
	{
		if (!addr || !addrlen)
			return -1;

		if (*addrlen < sizeof(target))
			copylen = *addrlen;

		target.sin_family = AF_INET;
		target.sin_addr.s_addr = htonl(INADDR_ANY);
		target.sin_port = htons(PORT);

		memcpy(addr, &target, copylen);
		*addrlen = copylen;
		return 0;
	}
	else
	{
		debug_info("Nomal getsockname function~\n");
		return original_getsockname(sockfd, addr, addrlen);
	}
}
