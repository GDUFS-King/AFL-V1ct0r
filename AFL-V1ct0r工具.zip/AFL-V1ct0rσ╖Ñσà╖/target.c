#include <stdlib.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>


typedef int(*func)(int sockfd, char buffer[20]);


int main (int argc, char** argv) {
	
    char buffer[20];
	void* handler = dlopen("./fuzz_target.so", RTLD_LAZY);
	if (!handler)
	{
	    fprintf (stderr, "dlopen Error:%s\n", dlerror ());
	    return -1;
	}
	func funcc1 = (func)dlsym(handler,"func_0x16a3");
	
	if (!funcc1) 
	{
	    fprintf (stderr, "dlsym Error:%s\n", dlerror ());
	    return -1;
	}
	funcc1(3,buffer);
	dlclose(handler);
	return 0;
}

