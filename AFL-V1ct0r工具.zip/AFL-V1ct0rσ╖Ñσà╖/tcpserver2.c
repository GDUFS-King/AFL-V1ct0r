#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define MAXLINE 100

int main(int argc, char *argv[]) 
{
    int listenfd,connfd;
    struct sockaddr_in servaddr;
    int port = atoi(argv[1]);
    if( (listenfd = socket(AF_INET,SOCK_STREAM,0)) == -1) {
        printf(" create socket error: %s (errno :%d)\n",strerror(errno),errno);
        return 0;
    }
	

    memset(&servaddr,0,sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);


    if ( bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1) {
        printf(" bind socket error: %s (errno :%d)\n",strerror(errno),errno);
        return 0;
    }

    if( listen(listenfd,10) == -1) {
        printf(" listen socket error: %s (errno :%d)\n",strerror(errno),errno);
        return 0;
    }
    if( (connfd = accept(listenfd, (struct sockaddr *)NULL, NULL))  == -1) {
            printf(" accpt socket error: %s (errno :%d)\n",strerror(errno),errno);
            return 0;
        }
    printf("====waiting for client's request=======\n");
    while(1)
    {
        funcc(connfd);
        // close(connfd);
    }
    close(listenfd);
    return 0;
}
int funcc(int connfd)
{
	char buf[110];
	send(connfd,"Welcome to a easy talk~\n",26,0);
	int n = recv(connfd,buf,MAXLINE,0);
    buf[n] = '\x00';
	char buff[50] = "So this is what you send???:";
    signed int a = (int)(buf[1]);
    unsigned int mm = (unsigned int)a;
    strncpy(buff,buf,mm);
	printf(buff);
	return 0;
}