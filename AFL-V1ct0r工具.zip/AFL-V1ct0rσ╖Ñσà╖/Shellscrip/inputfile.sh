#!/bin/bash

cd Fuzzin/fuzzin1
touch inputfile
cd ..

cd fuzzin2
touch inputfile
cd ..

cd fuzzin3
touch inputfile
cd ..

cd fuzzin4
touch inputfile
cd ..
