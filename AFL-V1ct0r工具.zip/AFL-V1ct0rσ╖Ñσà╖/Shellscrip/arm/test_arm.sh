#!/bin/bash

if [ -f "arm_target1" ];then
  LD_PRELOAD=./Hookso/arm_hooksock.so qemu-arm -L /usr/arm-linux-gnueabi ./arm_target1
  if [ -f "arm_target2" ];then
  	LD_PRELOAD=./Hookso/arm_hooksock.so qemu-arm -L /usr/arm-linux-gnueabi ./arm_target2
  	if [ -f "arm_target3" ];then
  		LD_PRELOAD=./Hookso/arm_hooksock.so qemu-arm -L /usr/arm-linux-gnueabi ./arm_target3
  		if [ -f "arm_target4" ];then
  			LD_PRELOAD=./Hookso/arm_hooksock.so qemu-arm -L /usr/arm-linux-gnueabi ./arm_target4
  		fi
  	fi
  	
  fi

fi