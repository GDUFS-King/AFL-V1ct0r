#!/bin/bash

export QEMU_RESERVED_VA=0x1000000

export QEMU_LD_PREFIX=/usr/arm-linux-gnueabi

LD_PRELOAD=./Hookso/arm_hooksock.so afl-fuzz -i Fuzzin/fuzzin1 -o Fuzzout/fuzzout1 -Q -S fuzz3 ./arm_target1