#!/bin/bash

gnome-terminal --title="change-test" -x bash -c "sh ./Shellscrip/arm/arm_mode.sh"

