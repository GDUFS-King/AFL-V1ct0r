#!/bin/bash

if [ -f "arm_target1" ];then
  echo "Exist 1"
  if [ -f "arm_target2" ];then
  	echo "Exist 2"
  	if [ -f "arm_target3" ];then
  		echo "Exist 3"
  		if [ -f "arm_target4" ];then
  			echo "Full!!!"
  			else
  			arm-linux-gnueabi-gcc -o arm_target4 target.c -ldl
        chmod 777 arm_target4
  		fi
  		else
  		arm-linux-gnueabi-gcc -o arm_target3 target.c -ldl
      chmod 777 arm_target3
  	fi
  	else
  	arm-linux-gnueabi-gcc -o arm_target2 target.c -ldl
    chmod 777 arm_target2
  fi
  else
  arm-linux-gnueabi-gcc -o arm_target1 target.c -ldl
  chmod 777 arm_target1
fi
