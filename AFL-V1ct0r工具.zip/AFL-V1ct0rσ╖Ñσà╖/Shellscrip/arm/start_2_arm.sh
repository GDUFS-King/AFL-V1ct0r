#!/bin/bash

echo "Start all arm_Fuzzing job!!!"
gnome-terminal -t "Fuzz1-test" -x bash -c "sh ./Shellscrip/arm/start_arm1.sh;exec bash;"
gnome-terminal -t "Fuzz2-test" -x bash -c "sh ./Shellscrip/arm/start_arm2.sh;exec bash;"