#!/bin/bash
echo "Start test before fuzz!!!"
gnome-terminal -t "Test" -x bash -c "sh ./Shellscrip/arm/test_arm.sh;exec bash;"