#!/bin/bash

cd Hookso

sudo vim hooksockfunc.c
#创建３种架构的共享库
gcc hooksockfunc.c logging.c -o x86_64_hooksock.so -shared -fPIC  -w -Wall -DLINUX -ldl -lpthread

arm-linux-gnueabi-gcc hooksockfunc.c logging.c -o arm_hooksock.so -shared -w -fPIC  -Wall -DLINUX -ldl -lpthread

aarch64-linux-gnu-gcc hooksockfunc.c logging.c -o aarch64_hooksock.so -shared -w -fPIC  -Wall -DLINUX -ldl -lpthread
