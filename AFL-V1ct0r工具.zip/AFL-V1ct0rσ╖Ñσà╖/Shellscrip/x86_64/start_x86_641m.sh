#!/bin/bash

LD_PRELOAD=./Hookso/x86_64_hooksock.so afl-fuzz -i Fuzzin/fuzzin1 -o Fuzzout/fuzzout1 -Q -M fuzz1 ./x86_64_target1

