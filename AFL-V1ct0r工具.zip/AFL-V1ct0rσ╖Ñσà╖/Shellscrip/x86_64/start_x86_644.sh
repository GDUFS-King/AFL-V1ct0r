#!/bin/bash

LD_PRELOAD=./Hookso/x86_64_hooksock.so afl-fuzz -i Fuzzin/fuzzin4 -o Fuzzout/fuzzout4 -Q ./x86_64_target4

