#!/bin/bash

LD_PRELOAD=./Hookso/x86_64_hooksock.so afl-fuzz -i Fuzzin/fuzzin1 -o Fuzzout/fuzzout1 -Q ./x86_64_target1

