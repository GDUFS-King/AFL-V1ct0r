#!/bin/bash
echo "Start test before fuzz!!!"
gnome-terminal -t "Test" -x bash -c "sh ./Shellscrip/x86_64/test_x86.sh;exec bash;"