#!/bin/bash

gnome-terminal --title="x86_64-mode" -x bash -c "sh ./Shellscrip/x86_64/x86_64_mode.sh"

