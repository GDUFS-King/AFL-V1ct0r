#!/bin/bash
#根据文件名进行排除法
if [ -f "x86_64_target1" ];then
  echo "Exist 1"
  if [ -f "x86_64_target2" ];then
  	echo "Exist 2"
  	if [ -f "x86_64_target3" ];then
  		echo "Exist 3"
  		if [ -f "x86_64_target4" ];then
  			echo "Full!!!"
  			else
  			gcc -o x86_64_target4 target.c -ldl
        chmod 777 x86_64_target4
  		fi
  		else
  		gcc -o x86_64_target3 target.c -ldl
      chmod 777 x86_64_target3
  	fi
  	else
  	gcc -o x86_64_target2 target.c -ldl
    chmod 777 x86_64_target2
  fi
  else
  gcc -o x86_64_target1 target.c -ldl
  chmod 777 x86_64_target1
fi
