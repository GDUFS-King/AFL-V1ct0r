#!/bin/bash

LD_PRELOAD=./Hookso/x86_64_hooksock.so afl-fuzz -i Fuzzin/fuzzin3 -o Fuzzout/fuzzout3 -Q ./x86_64_target3

