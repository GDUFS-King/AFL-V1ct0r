#!/bin/bash
echo "Start all x86_Fuzzing job!!!"
gnome-terminal -t "Fuzz1-test" -x bash -c "sh ./Shellscrip/x86_64/start_x86_641.sh;exec bash;"
gnome-terminal -t "Fuzz2-test" -x bash -c "sh ./Shellscrip/x86_64/start_x86_642.sh;exec bash;"
gnome-terminal -t "Fuzz3-test" -x bash -c "sh ./Shellscrip/x86_64/start_x86_643.sh;exec bash;"