#!/bin/bash

if [ -f "x86_64_target1" ];then
  LD_PRELOAD=./Hookso/x86_64_hooksock.so ./x86_64_target1
  if [ -f "x86_64_target2" ];then
  	LD_PRELOAD=./Hookso/x86_64_hooksock.so ./x86_64_target2
  	if [ -f "x86_64_target3" ];then
  		LD_PRELOAD=./Hookso/x86_64_hooksock.so ./x86_64_target3
  		if [ -f "x86_64_target4" ];then
  			LD_PRELOAD=./Hookso/x86_64_hooksock.so ./x86_64_target4
  		fi
  	fi
  	
  fi

fi