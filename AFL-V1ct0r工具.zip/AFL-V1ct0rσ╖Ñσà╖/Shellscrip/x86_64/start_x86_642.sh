#!/bin/bash

LD_PRELOAD=./Hookso/x86_64_hooksock.so afl-fuzz -i Fuzzin/fuzzin2 -o Fuzzout/fuzzout2 -Q ./x86_64_target2

