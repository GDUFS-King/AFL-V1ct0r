#!/bin/bash
#清空生成的fuzz目标文件
rm -rf x86_64_target1 x86_64_target2 x86_64_target3 x86_64_target4
rm -rf arm_target1 arm_target2 arm_target3 arm_target4
rm -rf aarch64_target1 aarch64_target2 aarch64_target3 aarch64_target4
#刷新输入输出文件
rm -rf Fuzzout/*
rm -rf Fuzzin/*
rm -rf fuzz_target.so
#重新创建文件
cd Fuzzin
mkdir fuzzin1 fuzzin2 fuzzin3 fuzzin4

cd ..
cd Fuzzout
mkdir fuzzout1 fuzzout2 fuzzout3 fuzzout4
#初始化样例文件
cd ..
bash -c "sh ./Shellscrip/inputfile.sh"
