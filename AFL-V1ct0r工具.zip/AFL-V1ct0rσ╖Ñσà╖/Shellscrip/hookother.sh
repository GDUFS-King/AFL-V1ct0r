#!/bin/bash

cd Hookso

sudo vim hookothers.c

gcc hookothers.c logging.c -o x86_64_hookother.so -shared -fPIC  -Wall -w -DLINUX -ldl -lpthread

arm-linux-gnueabi-gcc hookothers.c logging.c -o arm_hookother.so -shared -fPIC -w -Wall -DLINUX -ldl -lpthread

aarch64-linux-gnu-gcc hookothers.c logging.c -o aarch64_hookother.so -shared -fPIC -w -Wall -DLINUX -ldl -lpthread
