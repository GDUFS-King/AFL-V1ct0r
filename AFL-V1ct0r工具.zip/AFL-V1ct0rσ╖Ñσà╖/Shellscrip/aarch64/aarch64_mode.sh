#!/bin/bash

cd AFLplusplus-2.66c/qemu_mode
rm -rf qemu-3.1.1

CPU_TARGET=aarch64 ./build_qemu_support.sh

cd ..
echo 9877 | sudo -S make install
