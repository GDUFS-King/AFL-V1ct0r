#!/bin/bash

if [ -f "aarch64_target1" ];then
  LD_PRELOAD=./Hookso/aarch64_hooksock.so qemu-aarch64 -L /usr/aarch64-linux-gnu ./aarch64_target1
  if [ -f "aarch64_target2" ];then
  	LD_PRELOAD=./Hookso/aarch64_hooksock.so qemu-aarch64 -L /usr/aarch64-linux-gnu ./aarch64_target2
  	if [ -f "aarch64_target3" ];then
  		LD_PRELOAD=./Hookso/aarch64_hooksock.so qemu-aarch64 -L /usr/aarch64-linux-gnu ./aarch64_target3
  		if [ -f "aarch64_target4" ];then
  			LD_PRELOAD=./Hookso/aarch64_hooksock.so qemu-aarch64 -L /usr/aarch64-linux-gnu ./aarch64_target4
  		fi
  	fi
  	
  fi

fi