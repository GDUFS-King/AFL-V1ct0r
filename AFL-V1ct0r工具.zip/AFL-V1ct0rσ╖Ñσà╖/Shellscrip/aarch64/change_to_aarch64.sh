#!/bin/bash

gnome-terminal --title="change-test" -x bash -c "sh ./Shellscrip/aarch64/aarch64_mode.sh"

