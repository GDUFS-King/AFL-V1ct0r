#!/bin/bash
echo "Start test before fuzz!!!"
gnome-terminal -t "Test" -x bash -c "sh ./Shellscrip/aarch64/test_aarch64.sh;exec bash;"