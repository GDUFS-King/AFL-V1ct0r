#!/bin/bash

if [ -f "aarch64_target1" ];then
  echo "Exist 1"
  if [ -f "aarch64_target2" ];then
  	echo "Exist 2"
  	if [ -f "aarch64_target3" ];then
  		echo "Exist 3"
  		if [ -f "aarch64_target4" ];then
  			echo "Full!!!"
  			else
  			aarch64-linux-gnu-gcc -o aarch64_target4 target.c -ldl
        chmod 777 aarch64_target4
  		fi
  		else
  		aarch64-linux-gnu-gcc -o aarch64_target3 target.c -ldl
      chmod 777 aarch64_target3
  	fi
  	else
  	aarch64-linux-gnu-gcc -o aarch64_target2 target.c -ldl
    chmod 777 aarch64_target2
  fi
  else
  aarch64-linux-gnu-gcc -o aarch64_target1 target.c -ldl
  chmod 777 aarch64_target1
fi
