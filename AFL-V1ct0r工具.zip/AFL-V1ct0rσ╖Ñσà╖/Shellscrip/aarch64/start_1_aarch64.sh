#!/bin/bash

echo "Start all arm_Fuzzing job!!!"
gnome-terminal -t "FuzzM-test" -x bash -c "sh ./Shellscrip/aarch64/start_aarch641m.sh;exec bash;"
gnome-terminal -t "FuzzS1-test" -x bash -c "sh ./Shellscrip/aarch64/start_aarch641s1.sh;exec bash;"
gnome-terminal -t "FuzzS2-test" -x bash -c "sh ./Shellscrip/aarch64/start_aarch641s2.sh;exec bash;"
