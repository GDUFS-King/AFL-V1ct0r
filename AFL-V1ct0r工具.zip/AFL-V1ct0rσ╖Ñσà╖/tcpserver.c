#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <time.h>

#define QUEUE 20
char table[64]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
int heap(int conn,char buffer[1024]);
int funcc(int conn);
int fmt(int conn,char buffer[1024]);
// int init();
char buffe[100]="hello!";

int stack(int conn, char buffer[1024]);
int mem(int conn,char buffer[1024]);
int main(int argc, char *argv[]) 
{
    // init();
    fd_set rfds;
    int port = atoi(argv[1]);
    char buffer[1024];
    char buffer3[1024]="";
    char buffer1[1024]="";
    char buffer4[1024]="ACK\n";
    char buffer2[1024]="Wrong!try again?\n";
    int sj=0;
    int flag = 0;
    struct timeval tv;
    int retval, maxfd;
    int ss = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_sockaddr;
    server_sockaddr.sin_family = AF_INET;
    server_sockaddr.sin_port = htons(port);
    //printf("%d\n",INADDR_ANY);
    server_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    if(bind(ss, (struct sockaddr* ) &server_sockaddr, sizeof(server_sockaddr))==-1) 
    {
        perror("bind");
        exit(1);
    }
    if(listen(ss, QUEUE) == -1) 
    {
        perror("listen");
        exit(1);
    }

    struct sockaddr_in client_addr;
    socklen_t length = sizeof(client_addr);
    ///成功返回非负描述字，出错返回-1
    int conn = accept(ss, (struct sockaddr*)&client_addr, &length);
    /*没有用来存储accpet返回的套接字的数组，所以只能实现server和单个client双向通信*/
    if( conn < 0 ) 
    {
        perror("connect");
        exit(1);
    }
    while(1) 
    {
        /*把可读文件描述符的集合清空*/
        FD_ZERO(&rfds);
        /*把标准输入的文件描述符加入到集合中*/
        FD_SET(0, &rfds);
        maxfd = 0;
        /*把当前连接的文件描述符加入到集合中*/
        FD_SET(conn, &rfds);
        /*找出文件描述符集合中最大的文件描述符*/    
        if(maxfd < conn)
            maxfd = conn;
        /*设置超时时间*/
        tv.tv_sec = 5;//设置倒计时
        tv.tv_usec = 0;
        /*等待聊天*/
        retval = select(maxfd+1, &rfds, NULL, NULL, &tv);
        if(retval == -1)
        {
            printf("select出错，客户端程序退出\n");
            break;
        }
        else if(retval == 0)
        {
            printf("服务端没有任何输入信息，并且客户端也没有信息到来，waiting...\n");
            continue;
        }
        else
        {
            /*客户端发来了消息*/
            if(FD_ISSET(conn,&rfds))
            {
                memset(buffer, 0 ,sizeof(buffer));
                memset(buffer1, 0 ,sizeof(buffer));
                if(sj==0)
                {
                    memset(buffer3, 0 ,sizeof(buffer));
                    srand((unsigned)time(NULL));
                    for(int i=0;i<4;i++)
                    {
                        char a[100];
                        memset(a, 0 ,sizeof(a));
                        a[0] = table[rand()%26];
                        strcat(buffer1,a);
                        buffer3[3-i] = a[0];
                    }
                    buffer3[4]='\n';
                    sj=1; 
                }
                strcat(buffer4,buffer1);
                int len = recv(conn, buffer, sizeof(buffer), 0);
                if(flag==0)
                {
                    if(strcmp(buffer, "SYN\n") == 0)
                    {
                        // printf("%s\n", buffer);
                        // printf("%s\n", buffer3);
                        send(conn, buffer4, strlen(buffer4) , 0);
                        flag = 1;
                    }
                    else
                    {
                        send(conn, buffer2, strlen(buffer2) , 0);
                    }
                }
                else
                {
                    // printf("buff-->%s\n", buffer);
                    // printf("buff3-->%s\n", buffer3);
                    if(strcmp(buffer, buffer3)==0)
                    {
                        funcc(conn);
                    }
                    else
                    {
                        send(conn, buffer2, strlen(buffer2),0);
                    }    
                }
            }
        }
    }
    close(conn);
    close(ss);
    return 0;
}
int funcc(int conn)
{

    char buffer[20];
    char buffer3[100]="Input your choice(S/P/H/Z/Q):\n";
    char buffer4[1024]="EXIT!";
    char buffer2[1024]="NNNNNN!!!!!";
    printf("okk!");

    while(1)
    {
            /*客户端发来了消息*/
                memset(buffer, 0 ,sizeof(buffer));
                send(conn, buffer3, strlen(buffer3),0);
                int len = recv(conn, buffer, sizeof(buffer), 0);
                // signed int a = (int)(buffer[1]);
                
                switch(buffer[0])
                {
                    case 'P':
                        fmt(conn,buffer);
                        // send(conn, buffer, strlen(buffer),0);
                        break;
                    case 'S':
                        stack(conn,buffer);
                        break;
                    case 'H':
                        heap(conn,buffer);
                        break;
                    case 'Z':
                        mem(conn,buffer);
                        break;
                    case 'Q':
                        send(conn, buffer4, strlen(buffer4),0);
                        exit(0);
                        break;
                    default:
                        break;
                }
    }
    return 0;
}

int fmt(int conn,char buffer[20])
{
    char buffer6[200];
    char bufg2[100]="I want to store what you say!!!\n";
    send(conn, bufg2, strlen(bufg2),0);
    int lenb = recv(conn, buffer6, sizeof(buffer6), 0);
    printf("Information from client:");
    printf(buffer6);

    return 0;
}


int stack(int conn, char buffer[20])
{
    
    char buffer7[160];
    char bufg[100]="I will send you what you send~\n";

    send(conn, bufg, strlen(bufg),0);
    int len = recv(conn, buffer7, sizeof(buffer7), 0);
    strncpy(buffer,buffer7,strlen(buffer7));
    send(conn, buffer, strlen(buffer),0);
    return 0;
}

int heap(int conn, char buffer[20])
{
    char *pp[10];
    pp[0] = malloc(0x8);
    pp[1] = malloc(0x8);
    char buffer8[1024];
    char bufv[100]="Input something?\n";

    send(conn, bufv, strlen(bufv),0);
    int len2 = recv(conn, buffer8, sizeof(buffer8), 0);
    strncpy(pp[0],buffer8,strlen(buffer8));
    printf("info from client:%s",pp[0]);

    // if(buffer8[1]!=buffer8[2])
    // {
    //     free(pp[0]);
    //     free(pp[1]);
    // }

    free(pp[0]);
    free(pp[1]);
    return 0;
}

int mem(int conn,char buffer[20])
{
    char buffer9[512];
    char buffe[1024];
    char bufo[100]="How many times do you want to repeat?\n";

    send(conn, bufo, strlen(bufo),0);
    int len3 = recv(conn, buffer9, sizeof(buffer9), 0);
    signed int a = (int)(buffer9[1]);
    unsigned int mm = (unsigned int)a;
    strncpy(buffe,buffer9,mm);
    for(int i=0;i<mm;i++)
    {
        send(conn, buffe, strlen(buffe),0);
    }

    return 0;
}
