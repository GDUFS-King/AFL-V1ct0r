### 一、AFL-Fuzz的安装

将压缩包解压后，放到虚拟机中，进入文件夹，执行下面的命令进行安装：

```shell
make
sudo make install
```

afl-fuzz安装说明：

[-] Error: 'bison' not found, please install first.
[-] Error: 'flex' not found, please install first.

缺失库的话先安装下库，关于afl-fuzz的具体使用，可以参考网上的很多blog~



### 二、LIEF库的下载安装

参考github官网链接：

https://github.com/lief-project/LIEF

这里使用python3实现函数调用



### 三、qemu、arm和aarch64的环境下载与安装

```shell
#安装qemu
sudo apt-get install qemu
#sudo apt-get install qemu-user(ubuntu20下命令)
#更新一下
sudo apt-get update
#安装32位的依赖库
sudo apt-get install -y gcc-arm-linux-gnueabi
#运行32位的动态链接程序方法
qemu-arm -L /usr/arm-linux-gnueabi ./文件
#安装64位的依赖库
sudo apt-get install -y gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
#运行64位的动态链接程序方法
qemu-aarch64 -L /usr/aarch64-linux-gnu ./文件
#安装gdb调试工具
sudo apt-get install git gdb gdb-multiarch
```

