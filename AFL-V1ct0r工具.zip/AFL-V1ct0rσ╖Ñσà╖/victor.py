# -*- coding: utf-8 -*-
import os
import lief
import sys
import argparse
from pathlib import Path

#测试对象的使用标志值
target_mode = 0
x86_64 = 1
arm = 2
aarch64 = 3

#主函数，包含工具各个模块的功能实现
def main(filename,sourcename):
	elf = 0
	choice = 0
	print("Successfully load "+filename+" and "+sourcename+"!")
	while 1:
		author_name()
		menu()
		choice = int(input())

		if choice==1:
			Create_so(filename)

		elif choice==2:
			Design_target(sourcename)

		elif choice==3:
			Create_target()

		elif choice==4:
			Edit_hookso()

		elif choice==5:
			AFL_fuzz()

		elif choice==6:
			Reflash()

		elif choice==7:
			Change_cpu_target()
		elif choice==8:
			exit(0)
		else:
			error_message()
			continue

#开发者id信息
def author_name():
	print("**************************************************************")
	print("**11*****11**11****11111***1111111111****11111******111111****")
	print("**11*****11**11***11***11******11*******11***11*****11***11***")
	print("***11***11***11**11************11******11*****11****11**11****")
	print("****11*11****11**11************11******11*****11****1111******")
	print("*****111*****11***11***11******11*******11***11*****11**11****")
	print("******1******11****11111*******11********11111******11****11**")
	print("**************************************************************")

#切换cpu的模拟运行架构，可选x86_64\arm\aarch64
def Change_cpu_target():
	print("Please select a cpu_target:")
	print("1.x86_64")
	print("2.arm")
	print("3.aarch64")
	print("Your choice>>>> ")
	choice = int(input())
	if choice==1:
		os.system("./Shellscrip/x86_64/change_to_x86_64.sh")
	elif choice==2:
		os.system("./Shellscrip/arm/change_to_arm.sh")
	elif choice==3:
		os.system("./Shellscrip/aarch64/change_to_aarch64.sh")
	else:
		error_message()

#工具菜单栏，展示拥有的功能
def menu():
	print("-----AFL-V1ct0r-T00L-----")
	print("1.Declare the function")
	print("2.Design the target")
	print("3.Create the target")
	print("4.Edit HookSo")
	print("5.AFL Fuzz the target")
	print("6.Reflash all things")
	print("7.Change the AFL-CPU_TARGET")
	print("8.Exit")
	print("Your choice>>>> ")

#检查ｆｕｚｚ测试文件的个数
def file_exist(filename):
	file_num = 0
	for i in range(4):
		if os.path.exists(filename+str(i+1)):
			file_num += 1
		else:
			file_num += 0
	return file_num

#刷新功能，清空已经存在的测试文件，保证下次测试有个干净完整的环境
def Reflash():
	os.system("./Shellscrip/reflash.sh")
	print("Reflash successfully!!!")

#对ｈｏｏｋ函数池进行编辑，分为ｓｏｃｋｅｔ类和其他类２方面，可实现自定义的ｈｏｏｋ函数
def Edit_hookso():
	print("Which file do you want to edit?")
	print("1.hooksock.c")
	print("2.hookothers.c")
	kk = int(input())
	if kk==1:
		os.system("./Shellscrip/hooksock.sh")
	elif kk==2:
		os.system("./Shellscrip/hookother.sh")
	else:
		error_message()

#创建ｆｕｚｚ的目标文件，不同架构生成不同的文件
def Create_target():
	while 1:
		Select_Architecture()
		select = int(input())

		if select==1:
			Create_x86_64_target()
			break
		elif select==2:
			Create_arm_target()
			break
		elif select==3:
			Create_aarch64_target()
			break

#　输入文件菜单
def inputfilemenu():
	print("Which file do you want to edit?")
	print("1.fuzzin1")
	print("2.fuzzin2")
	print("3.fuzzin3")
	print("4.fuzzin4")
	print("Your choice>>>> ")

#在最终的ｆｕｚｚ开始前，需要进行本地运行测试，避免误报或者长时间ｆｕｚｚ无效果
def test_target():
	print("Before fuzz we should test the target!!!")
	if target_mode==x86_64:
		os.system("./Shellscrip/x86_64/test.sh")
	elif target_mode==arm:
		os.system("./Shellscrip/arm/test.sh")
	elif target_mode==aarch64:
		os.system("./Shellscrip/aarch64/test.sh")
	else:
		error_message()
	
#开启真正的ｆｕｚｚ，ｆｕｚｚ之前需要先编辑下输入样例
def AFL_fuzz():
	#ｆｕｚｚ前先运行测试，确保正常运转
	while 1:
		print("Before fuzz we should test the target(y/n)")
		sel = str(input())
		if sel=='y':
			test_target()
		else:
			break
	
	while 1:
		print("Edit the input file? y/n")
		sel = str(input())
		if sel=='y':
			inputfilemenu()
			nu = int(input())
			#初始化操作，编辑选定的输入文件夹中的输入样例
			if nu==1:
				os.system("sudo vim Fuzzin/fuzzin1/inputfile")
			elif nu==2:
				os.system("sudo vim Fuzzin/fuzzin2/inputfile")
			elif nu==3:
				os.system("sudo vim Fuzzin/fuzzin3/inputfile")
			elif nu==4:
				os.system("sudo vim Fuzzin/fuzzin4/inputfile")
			else:
				error_message()
			#初始化结束，开始ｆｕｚｚ工作
		elif sel=='n':
			fuzzstart()
			break
		else:
			error_message()

#报错信息输出
def error_message():
	print("Wrong input....try again?")

#ａｒｍ模式的切换
def arm_mode():
	os.system("./Shellscrip/change.sh")

#开始真正的ｆｕｚｚ
def fuzzstart():
	# print(arm)
	
	print("All things done!Let's Begin Fuzz!!!")
	print("mode--->"+hex(x86_64))
	#在ｘ８６模式下选择想要ｆｕｚｚ的程序片段个数
	if target_mode==x86_64:
		num = file_exist("x86_64_target")
		if num==1:
			os.system("./Shellscrip/x86_64/start_1_x86.sh")#并行ｆｕｚｚ
		elif num==2:
			os.system("./Shellscrip/x86_64/start_2_x86.sh")#２路ｆｕｚｚ
		elif num==3:
			os.system("./Shellscrip/x86_64/start_3_x86.sh")#３路ｆｕｚｚ
		elif num==4:
			os.system("./Shellscrip/x86_64/start_4_x86.sh")#４路ｆｕｚｚ
		else:
			error_message()
	#在ａｒｍ模式下选择想要ｆｕｚｚ的程序片段个数	
	elif target_mode==arm:
		num = file_exist("arm_target")
		if num==1:
			os.system("./Shellscrip/arm/start_1_arm.sh")
		elif num==2:
			os.system("./Shellscrip/arm/start_2_arm.sh")
		elif num==3:
			os.system("./Shellscrip/arm/start_3_arm.sh")
		elif num==4:
			os.system("./Shellscrip/arm/start_4_arm.sh")
		else:
			error_message()
	#在ａａｒｃｈ６４模式下选择想要ｆｕｚｚ的程序片段个数
	elif target_mode==aarch64:
		num = file_exist("aarch64_target")
		if num==1:
			os.system("./Shellscrip/aarch64/start_1_aarch64.sh")
		elif num==2:
			os.system("./Shellscrip/aarch64/start_2_aarch64.sh")
		elif num==3:
			os.system("./Shellscrip/aarch64/start_3_aarch64.sh")
		elif num==4:
			os.system("./Shellscrip/aarch64/start_4_aarch64.sh")
		else:
			error_message()
	else:
		error_message()
		
#将二进制程序转化成动态链接库，并对程序中想要调用的函数进行声明
def Create_so(infile):
	addr = []
	elf = lief.parse(infile)#导入二进制程序

	print("How many function do you want to fuzz?(Max is 4!!!)")
	global num 
	number = int(input())
	#限定最大数量级为４
	if number>=0 and number<=4:
		num = number 
		for i in range(num):
			print("please input the funcaddr(Hex) "+str(i+1))
			get_addr = int(input(),16)
			addr.append(get_addr)
		
		#对存储的输入地址进行声明操作
		for i in range(len(addr)):
			#声明调用的函数，并用地址符号重新命名
			elf.add_exported_function(addr[i], "func_"+hex(addr[i]))
		#导出为相应的共享库
		elf.write("fuzz_target.so")
		print("Create fuzz_target.so successfully!")
	else:
		error_message()

#编辑ｔａｒｇｅｔ.c，自定义测试目标文件
def Design_target(sourcename):
	os.system("sudo vim '{}'".format(sourcename))
	print("Designed!")

#创建x86_64架构的程序
def Create_x86_64_target():
	os.system("./Shellscrip/x86_64/create_x86_target.sh")
	print("Create x86_64_target successfully!")

#创建ａｒｍ架构的程序
def Create_arm_target():
	os.system("./Shellscrip/arm/create_arm_target.sh")
	print("Create arm_target successfully!")

#创建ａａｒｃｈ６４架构的程序
def Create_aarch64_target():
	os.system("./Shellscrip/aarch64/create_aarch64_target.sh")
	print("Create aarch64_target successfully!")

#选择需要的３种架构之一
def Select_Architecture():
	print("Please input the Architecture of bin:")
	print("1.x86-64")
	print("2.arm")
	print("3.aarch64")
	print("Your choice>>>> ")

#退出工具，结束
def Exit_it():
	print("Thanks for your use!")
	exit(0)

#初始化操作，含有ｈｅｌｐ的功能，对测试文件＼ｔａｒｇｅｔ.c＼测试类型进行检测
def Init():
	parser = argparse.ArgumentParser()
	parser.add_argument('-f','--args_file',help="The bin program will be change into library")
	parser.add_argument('-s','--args_source',help="The target.c will be FUzzed!")
	parser.add_argument('-t','--args_type',help="The Architecture type of the Qemu(choose arm or x86 or aarch64)")
	args = parser.parse_args()
	filename = args.args_file
	Atype = args.args_type
	global arm
	global aarch64
	global x86_64
	global target_mode
	if Atype=="arm":
		target_mode = 2

	elif Atype=="aarch64":
		target_mode = 3

	elif Atype=="x86_64":
		target_mode = 1
	else:
		print("[-] Type error! try again")
	# print(arm)
	sourcename = args.args_source
	flag1 = Path(filename).is_file()
	flag2 = 0
	l = len(sourcename)
	
	if sourcename[l-2]=='.' and sourcename[l-1]=='c':
		flag2 = Path(sourcename).is_file()

	if flag1 and flag2:
		return filename,sourcename

	elif not flag1 and flag2:
		print("[-] '{}' is not exist or not a valid file!".format(filename))
		exit(0)

	elif flag1 and not flag2:
		print("[-] '{}' is not exist or not a valid file!".format(sourcename))
		exit(0)

	else:
		print("[-] '{0}' and '{1}' are not exist or not valid files!".format(filename,sourcename))
		exit(0)


if __name__ == '__main__':
	filename,sourcename = Init()

	main(filename,sourcename)


