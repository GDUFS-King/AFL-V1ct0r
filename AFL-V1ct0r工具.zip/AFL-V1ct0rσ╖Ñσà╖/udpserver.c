#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 1234
#define MAXDATASIZE 100

int main()
{
       int sockfd;
       struct sockaddr_in server;
       struct sockaddr_in client;
       socklen_t addrlen;
       int num;
       char buf[MAXDATASIZE];

       if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
       {
              perror("Creatingsocket failed.");
              exit(1);
       }

       bzero(&server,sizeof(server));
       server.sin_family=AF_INET;
       server.sin_port=htons(PORT);
       server.sin_addr.s_addr= htonl(INADDR_ANY);
       if(bind(sockfd, (struct sockaddr *)&server, sizeof(server)) == -1)
       {
              perror("Bind()error.");
              exit(1);
       }   

       addrlen=sizeof(client);
       funcc(sockfd,client,addrlen);
       // while(1)  
       // {
       //        num =recvfrom(sockfd,buf,MAXDATASIZE,0,(struct sockaddr*)&client,&addrlen);                                   
       //        if (num < 0)
       //        {
       //               perror("recvfrom() error\n");
       //               exit(1);
       //        }

       //        buf[num] = '\0';
       //        printf("You got a message (%s%) from client.\nIt's ip is%s, port is %d.\n",buf,inet_ntoa(client.sin_addr),htons(client.sin_port)); 
       //        sendto(sockfd,"Welcometo my server.\n",22,0,(struct sockaddr *)&client,addrlen);
       //        if(!strcmp(buf,"bye"))
       //               break;
       // }
       close(sockfd);
}
int funcc(int sockfd,struct sockaddr_in client,socklen_t addrlen)
{
    char buffer[20];
    char bufg[200]="Welcometo my server.\n1.Show message\n2.store by stack \n3.store by heap \n4.Reapte message any times \n5.Exit \nYour choice: \n";

    // sendto(sockfd,"Welcometo my server.\n",22,0,(struct sockaddr *)&client,addrlen);
    while(1)
    {

            /*客户端发来了消息*/
                sendto(sockfd,bufg,strlen(bufg),0,(struct sockaddr *)&client,addrlen);
                memset(buffer, 0 ,sizeof(buffer));
                // signed int a = (int)(buffer[1]);
                int num =recvfrom(sockfd,buffer,sizeof(buffer),0,(struct sockaddr*)&client,&addrlen);     
                switch(buffer[0])
                {
                    case '1':
                        fmt(sockfd,buffer,client,addrlen);
                        
                        break;
                    case '2':
                        stack(sockfd,buffer,client,addrlen);
                        break;
                    case '3':
                        heap(sockfd,buffer,client,addrlen);
                        break;
                    case '4':
                        mem(sockfd,buffer,client,addrlen);
                        break;
                    case '5':
                        sendto(sockfd,"See you!\n",8,0,(struct sockaddr *)&client,addrlen);
                        return 0;
                        break;
                    default:
                        break;
                }
    }
    return 0;
}

int fmt(int sockfd,char buffer[20],struct sockaddr_in client,socklen_t addrlen)
{
    char buffer6[200];
    memset(buffer6, 0 ,sizeof(buffer6));
    sendto(sockfd,"Say somethings?\n",22,0,(struct sockaddr *)&client,addrlen);
    recvfrom(sockfd,buffer6,sizeof(buffer6),0,(struct sockaddr*)&client,&addrlen);
    printf("Information from client:");
    printf(buffer6);
    return 0;
}


int stack(int sockfd, char buffer[20],struct sockaddr_in client,socklen_t addrlen)
{
    
    char buffer7[60];
    memset(buffer7, 0 ,sizeof(buffer7));
    sendto(sockfd,"I will store what you say by stack\n",36,0,(struct sockaddr *)&client,addrlen);
    recvfrom(sockfd,buffer7,sizeof(buffer7),0,(struct sockaddr*)&client,&addrlen);
    strcat(buffer7,"I hope you will get what you want~");
    printf("Store the message by stack:%s",buffer7);
    return 0;
}

int heap(int sockfd, char buffer[20],struct sockaddr_in client,socklen_t addrlen)
{
    char *pp[10];
    pp[0] = malloc(0x10);
    char buffer8[1024];
    memset(buffer8, 0 ,sizeof(buffer8));
    sendto(sockfd,"I will store what you say by heap\n",35,0,(struct sockaddr *)&client,addrlen);
    recvfrom(sockfd,buffer8,sizeof(buffer8),0,(struct sockaddr*)&client,&addrlen);
    strncpy(pp[0],buffer8,strlen(buffer8));
    printf("Store the message by heap:%s",pp[0]);

    if(buffer8[1]==buffer8[2])
    {
        free(pp[0]);
    }
    free(pp[0]);
    return 0;
}

int mem(int sockfd,char buffer[20],struct sockaddr_in client,socklen_t addrlen)
{
    char buffer9[512];
    char buffe[1024];
    memset(buffer9, 0 ,sizeof(buffer9));
    sendto(sockfd,"Say somethins again?\n",22,0,(struct sockaddr *)&client,addrlen);
    recvfrom(sockfd,buffer9,sizeof(buffer9),0,(struct sockaddr*)&client,&addrlen);
    signed int a = (int)(buffer9[1]);
    unsigned int mm = (unsigned int)a;
    strncpy(buffe,buffer9,mm);
    for(int i=0;i<mm;i++)
    {
        sendto(sockfd,buffer9,strlen(buffer9),0,(struct sockaddr *)&client,addrlen);
    }

    return 0;
}
